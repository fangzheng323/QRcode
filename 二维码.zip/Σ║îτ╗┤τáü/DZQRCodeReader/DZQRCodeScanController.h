//
//  DZQRCodeScanController.h
//  QRCode
//
//  Created by dengwei on 15/12/20.
//  Copyright (c) 2015年 dengwei. All rights reserved.
//

#import <UIKit/UIKit.h>

//扫描线颜色
#define kLineColor ([UIColor orangeColor].CGColor)

//扫描线宽度
#define kLineBorad 2

//扫描范围边框颜色
#define kRangeColor ([UIColor orangeColor].CGColor)

@interface DZQRCodeScanController : UIViewController

@end
