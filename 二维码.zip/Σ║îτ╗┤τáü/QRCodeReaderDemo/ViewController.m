//
//  ViewController.m
//  QRCodeReaderDemo
//
//  Created by dengwei on 15/12/25.
//  Copyright (c) 2015年 dengwei. All rights reserved.
//

#import "ViewController.h"
#import "DZQRCodeScanController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIButton *scanButton = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width / 2 - 40, [UIScreen mainScreen].bounds.size.height / 2 - 20, 80, 40)];
    scanButton.backgroundColor = [UIColor blueColor];
    [scanButton setTitle:@"Scan" forState:UIControlStateNormal];
    [scanButton addTarget:self action:@selector(scanAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:scanButton];
}

-(void)scanAction
{
    NSLog(@"scanAction");
    DZQRCodeScanController *scanActionController = [[DZQRCodeScanController alloc] init];
    [self presentViewController:scanActionController animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
