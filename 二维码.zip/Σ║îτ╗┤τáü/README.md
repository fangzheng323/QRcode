# QRCodeReader
二维码扫描

#Blog
My blog is [here](http://my.oschina.net/chars/blog). Welcome to visit!

#E-mail
Author:chars_d@126.com

Copyright © deng wei
